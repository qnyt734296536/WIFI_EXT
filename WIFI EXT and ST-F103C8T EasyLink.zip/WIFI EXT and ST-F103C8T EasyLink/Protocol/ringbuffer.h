/**
 * Project page: https://github.com/wangrn/ringbuffer
 * Copyright (c) 2013 Wang Ruining <https://github.com/wangrn>
 * @date 2013/01/16 13:33:20
 * @brief   a simple ringbuffer, DO NOT support dynamic expanded memory
 */

#ifndef RINGBUFFER_H
#define RINGBUFFER_H

#include <stdlib.h>

#define MAX_RINGBUFFER_LEN 	256
typedef struct {
    int rb_capacity;
    char  *rb_head;
    char  *rb_tail;
    char  rb_buff[MAX_RINGBUFFER_LEN];
}RingBuffer;
//struct RingBuffer;

// RingBuffer* rb_new(int capacity);
void rb_new(RingBuffer* rb);
void rb_free(RingBuffer *rb);

int rb_capacity(RingBuffer *rb);
int rb_can_read(RingBuffer *rb);
int rb_can_write(RingBuffer *rb);

int rb_read(RingBuffer *rb, void *data, int count);
int rb_write(RingBuffer *rb, const void *data, int count);

#endif
