/**
*庆科模块通用的AT命令
*/
#include <stdio.h>
#include "delay.h"
#include "ringbuffer.h"
#include "Hal_Usart/hal_uart.h"
#include "machip_at.h"


extern RingBuffer gUartRingBuff;	//wifi全局缓存


/**
*读取一条AT命令
*@param [out] respond 接收数据
*@patam [in] timeoutMs 超时时间ms
*@retva
*				-3 超时
*				-2 没有数据
*				-1错误
*				0 表示成功
*@note 
*		一般的AT命令回复都在都不超过2s
*回复的命令格式如下:
*[\r\n][+CMD:][para-1,para-2,para-3,......]<\r\n><STATUS><\r\n>
*读取思路是：每一条AT命令都是“\r\n”开头 ，必定有状态，必定是"\r\n结尾"
*事件没有state
*
*/

int CheckMachipAtData(PMachipAtRespond respond, int timeoutMs)
{
	int ret = -3;
	int useTime = 0;
	char atReadState = AT_READE_STATE_IDLE;
	int cmdIndex = 0;
	int stateIndex = 0;
	int dataIndex = 0;
	int oneTime = timeoutMs/3;
	//char dataFormat=0; //回复的数据结果类型， 0 表示只有state, 1表示具有+cmd+state
	uint8_t value = 0;
	uint8_t getState[10];
	char getCmd[MAX_AT_CMD];
	int nowLen = 0;
	uint8_t getData[MAX_AT_RESPOND_DATA_LEN];
	int dataNeedLen = 0;
	int dataMode = 0; //数据模式 0,表示透传，1表示json to hex
	int commaCount = 0; //逗号技术

	
	if(respond == NULL)
	{
		return -1;
	}
	
	
	if(rb_can_read(&gUartRingBuff) <= 0)
	{
		return -2;
	}
	while(useTime < timeoutMs)
	{
	
		if(atReadState == AT_READE_STATE_IDLE)
		{
			memset(getState, 0, sizeof(getState));
			memset(getCmd, 0, sizeof(getCmd));
			memset(getData, 0, sizeof(getData));
			cmdIndex = 0;
			stateIndex = 0;
			dataIndex = 0;
			dataNeedLen= 0;
			dataMode = 0;
			commaCount = 0;
		}
		nowLen = rb_can_read(&gUartRingBuff);
		//printf("useTime=%d,timeoutMs=%d,atReadState=%d,nowLen=%d\r\n",useTime , timeoutMs,atReadState, nowLen);
		if(nowLen <=0 )
		{
			Delay_ms(oneTime);
			useTime+=oneTime;
			continue;
		}
		
		if(atReadState == AT_READE_STATE_IDLE)
		{
				int aa = rb_read(&gUartRingBuff, &value, 1);
				//printf("aa=%d,value=%d \r\n",aa,value);
				//开始读头\r\n
				if( aa==1)
				{
					if(value == '\r')
					{
						if(rb_read(&gUartRingBuff, &value, 1) ==1)
						{
							if(value == '\n')
							{
								atReadState = AT_READE_STATE_HEADER; //读取到了"\r\n" 表示读取到了头
								useTime = 0;
							}
						}
					}	
				}	
		}
		if(atReadState == AT_READE_STATE_HEADER)
		{
			//开始读回复数据类型
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
				if(value =='+')
				{
					atReadState = AT_READE_STATE_NEED_CMD; //读到了数据格式
					//dataFormat = 1;//1表示具有+cmd+state
				}
				else
				{
					getState[0]=value; //如果只是状态，这里已经读取到了一个
					atReadState = AT_READE_STATE_NEED_END;
					//dataFormat = 0;
					stateIndex +=1;
				}
			}
		}
		if(atReadState == AT_READE_STATE_NEED_CMD)
		{
			//开始读cmd
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
				if(value !=':')
				{
					getCmd[cmdIndex++]= value;
				}
				else
				{
					if(strcmp(getCmd, "WEVENT") == 0
						||strcmp(getCmd, "CIPEVENT") == 0
						||strcmp(getCmd, "FOGEVENT") == 0
						||strcmp(getCmd, "ALINKEVENT") == 0
						||strcmp(getCmd, "OTAEVENT") == 0
					)
					{
						atReadState = AT_READE_STATE_NEED_EVENT; //这些命令是事件
					}
					else if(strcmp(getCmd, "FOGRECV") == 0)
					{
						atReadState = AT_READE_STATE_FOGRECV; //特殊处理
					}
					else
					{
						atReadState = AT_READE_STATE_NEED_DATA; //cmd 读取完成
					}
					
				}
			}
		}
		if(atReadState == AT_READE_STATE_NEED_DATA )
		{
			/*
			*读取数据和结束标记位
			*因为数据里面也包含了\r\n数据的结束标志需要用状态来判断\r\nOK\r\n, 或者\r\nERROR\r\n
			*+cmd+state模式的结束标记是\r\nOK\r\n, 或者\r\nERROR\r\n, state模式的结束标记是OK\r\n, 或者ERROR\r\n
			*接收数据的命令有有点特殊，比如AT+CIPRECV,AT+FOGRECV,要注意他们的本身数据就可能包含结束标志，这个需要根据格式读取完数据长度，然后读取结束标记
			*FOGRECV 没有 state
			*/
			
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
					getData[dataIndex++]= value;
					if(dataIndex >6)//strlen(\r\nOK\r\n)
					{
						if(strcmp((char *)&getData[dataIndex-6], "\r\nOK\r\n") == 0)
						{
							
							atReadState = AT_READE_STATE_END; //data+state 读取完成
							memcpy(getState,"OK",2);
							stateIndex = 2; //状态长度
							dataIndex -=6; //数据长度
							
						}
					}
					if(dataIndex >9)//strlen(\r\nERROR\r\n)
					{
						if(strcmp((char *)&getData[dataIndex-9], "\r\nERROR\r\n") == 0)
						{
							atReadState = AT_READE_STATE_END; //data+state 读取完成
							memcpy(getState,"ERROR",5);
							stateIndex = 5;
							dataIndex -=9;
						}
					}
			}
			
		}
		
		if(atReadState == AT_READE_STATE_FOGRECV) //+FOGRECV:<mode>,<len>,<data>
		{
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
				
					getData[dataIndex++]=value; 
					
					if(value ==',' && commaCount <2)
					{
						commaCount++;
						if(commaCount== 2) //<mode>,<len>,读取完成
						{
							sscanf((char *)getData,"%d,%d,",&dataMode,&dataNeedLen);
							
							printf("FOGRECV getData=%s, dataMode=%d, dataNeedLen=%d\r\n",getData, dataMode,dataNeedLen);
							memset(getData,0, sizeof(getData));
							dataIndex=0;
						}
					}

					if(commaCount ==2) //表示后面读取的数据是真实数据了
					{
						if(dataIndex == dataNeedLen)
						{
							atReadState = AT_READE_STATE_END;//有效数据里面保持的是原始数据，但是没有把数据模式上传上去
						}
					}

				}
					

		}
		if(atReadState == AT_READE_STATE_NEED_END)
		{
			/*在AT_READE_STATE_HEADER 状态的时候已经读取了一个字符*/
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
					getState[stateIndex++]= value;
					if(stateIndex >=4)//strlen(OK\r\n)
					{
						if(strcmp((char *)&getState[stateIndex-4], "OK\r\n") == 0)
						{
							atReadState = AT_READE_STATE_END; //state 读取完成
							memcpy(getState,"OK",2);
							stateIndex = 2;
						}
					}
					if(stateIndex >=7)//strlen(ERROR\r\n)
					{
						if(strcmp((char *)&getState[stateIndex-7], "ERROR\r\n") == 0)
						{
							atReadState = AT_READE_STATE_END; //state 读取完成
							memcpy(getState,"ERROR",5);
							stateIndex = 5;
						}
					}
			}
		}
		
		if(atReadState == AT_READE_STATE_NEED_EVENT)
		{
			//读取event
			if(rb_read(&gUartRingBuff, &value, 1) ==1)
			{
					getData[dataIndex++]= value;
					if(dataIndex >2)//strlen(\r\n)
					{
						if(strcmp((char *)&getData[dataIndex-2], "\r\n") == 0)
						{
							atReadState = AT_READE_STATE_END; //event 读取完成
							dataIndex -=2;
						}
					}
			}
		}
		if(atReadState == AT_READE_STATE_END)
		{
			memset(respond, 0, sizeof(TMachipAtRespond));
			memcpy(respond->cmd, getCmd, cmdIndex);
			memcpy(respond->data, getData, dataIndex);
			respond->dataLen = dataIndex;
			memcpy(respond->state, getState, stateIndex);
			ret = 0;
			break;
		}
		
	}
	
	if(cmdIndex != 0 || dataIndex != 0 || stateIndex !=0 )
	{
		printf("atReadState=%d,ret=%d\r\n",atReadState,ret);
		printf("cmdIndex=%d, cmd=%s\r\n",cmdIndex, getCmd);
		printf("dataIndex=%d, data is=%s\r\n",dataIndex,getData);
		//DebugHex(getData,dataIndex);
		printf("stateIndex=%d, state=%s\r\n",stateIndex, getState);
	
	}
	
	return ret; //超时
}


/**
*关闭串口回显
*@note 如果不关闭回显，发了什么就会返回什么
*/
int MachipCloseUartBackDisplay(void)
{
	SendStrToUsart(WIFI_UART, (u8*)"AT+UARTE=OFF\r");
	printf("AT+UARTE=OFF \r\n");

	return 0;
}




/**
*发送AT+WJAP=<ssid>,<key>连接AP
*/
int MachipStationConnectAp(uint8_t *ssid,char ssidLen, char * key)
{
	uint8_t cmd[128];
	int index = 0;
	//组装AT+WJAP=<ssid>,<key>
	memset(cmd, 0, sizeof(cmd));
	memcpy(cmd,"AT+WJAP=",strlen("AT+WJAP="));
	index +=strlen("AT+WJAP=");
	memcpy(cmd+index,ssid,ssidLen);
	index +=ssidLen;
	memcpy(cmd+index,",",1);
	index +=1;
	memcpy(cmd+index,key,strlen(key));
	index +=strlen(key);
	memcpy(cmd+index,"\r",1);
	index +=1;
	printf("MachipStationConnectAp index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, cmd, index);
	return 0;
}



/**
*启动一个网络链接
AT+CIPSTART=<id>,<type>,[domain],[remote_port],[local_port]
*note 
*立即生效。注意：当前 id 的连接，如果不是关闭状态，再次设置并连接时，无法成功执行，返回：ERROR。
*更改任何一个 id 的参数前，必须要手动关闭，即执行指令：AT+CIPSTOP=id\r，才能正确设置并连接
*/
int MachipStartNetWorkConnect(char id,char* type,char *domain,int remote_port,int local_port)
{
	char cmd[128];
	int index = 0;
	//组装AT+WJAP=<ssid>,<key>
	memset(cmd, 0, sizeof(cmd));
	index+=sprintf(cmd+index,"AT+CIPSTART=%d,%s,%s,%d\r",id,type,domain,remote_port);

	printf("MachipStartNetWorkConnect index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, (uint8_t*)cmd, index);
	return 0;
}

/**
*获取station 模式下链接状态
*@retval 
*	0表示STATION_UP, 表示成功连接AP； 
*  -1表示STATION_DOWN,表示连接 AP 失败；
*	-2表示CONNECTING,表示正在连接
*/
int GetStationConnectState(void)
{
	SendStrToUsart(WIFI_UART, (uint8_t *)"AT+WJAPS\r");
	printf("GetStationConnectState AT+WJAPS\r\n");
	return 0;
}


/**
*获取连接server状态
*@retval 

*/
int MachipGetNetServerConnect(char id)
{
	char cmd[128];
	int index = 0;
	//组装AT+WJAP=<ssid>,<key>
	memset(cmd, 0, sizeof(cmd));
	index+=sprintf(cmd+index,"AT+CIPSTATUS=%d\r",id);

	printf("MachipGetTcpServerConnectState index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, (uint8_t*)cmd, index);
	return 0;
}

/**
*停止连接server状态
*@retval 

*/
int MachipStopNetServerConnect(char id)
{
	char cmd[128];
	int index = 0;
	//组装AT+WJAP=<ssid>,<key>
	memset(cmd, 0, sizeof(cmd));
	index+=sprintf(cmd+index,"AT+CIPSTOP=%d\r",id);

	printf("MachipStopNetServerConnect index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, (uint8_t*)cmd, index);
	return 0;
}


/**
*开始配置网络,需要一个结束时间或者结束动作
*@param[in] mode 0 表示easylink ；1表示Airkiss
*@note 
*使用EasyLink
*整个过程可能会产生好几个事件，+WEVENT：AP_UP，+WEVENT：AP_DOWN，+WEVENT：STATION_UP
*/
int MachipStartSmart(char mode)
{
	char cmd[128];
	int index = 0;
	//AT+SMARTSTART=<type>
	memset(cmd, 0, sizeof(cmd));
	index+=sprintf(cmd+index,"AT+SMARTSTART=%d\r",mode);

	printf("MachipStopNetServerConnect index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, (uint8_t*)cmd, index);
	return 0;
}
/*
*停止配置网络
*@param[in] mode 0 表示easylink ；1表示Airkiss
*@note 
*/
int MachipStopSmart(char mode)
{
	char cmd[128];
	int index = 0;
	//AT+SMARTSTART=<type>
	memset(cmd, 0, sizeof(cmd));
	index+=sprintf(cmd+index,"AT+SMARTSTOP=%d\r",mode);

	printf("MachipStopNetServerConnect index=%d,cmd=%s\r\n",index,cmd);
	SendDataToUsart(WIFI_UART, (uint8_t*)cmd, index);
	return 0;
}

