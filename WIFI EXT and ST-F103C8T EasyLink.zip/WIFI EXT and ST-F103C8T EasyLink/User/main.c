/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_Usart/hal_uart.h"
#include "Hal_key/hal_key.h"
#include "ringbuffer.h"
#include "delay.h"
#include "machip_at.h"


/**
*云链接状态
*/
enum _module_work_state
{
  MODULE_WORK_STATE_IDLE,//空闲状态
	MODULE_WORK_STATE_NEED_CONNECT_AP,//需要连接AP
	MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,//需要检查连接AP
	MODULE_WORK_STATE_CONNECTED_AP,//连接AP成功
	MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER,//需要连接TCP
	MODULE_WORK_STATE_WAIT_CONNECTED_TCP_SERVER,//等待连接TCP服务
	MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE,//检查TCP 服务状态
	MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER, //需要停止一个连接
	MODULE_WORK_STATE_CONNECTED_TCP_SERVER,//连接TCP成功
	
	MODULE_WORK_STATE_NEED_SMARTSTART,//需要开始智能配网
	MODULE_WORK_STATE_SMARTSTART_STARTING,//正在使用配置网络
	MODULE_WORK_STATE_NEED_SMARTSTOP, //需要停止智能配网

	
};

#define MAIN_VERSION		"Ver EasyLink 1.0 "__DATE__



/*串口接收缓存*/
RingBuffer gUartRingBuff;	
/**全局的需要得到应答的命令*/
TNeedRespond gNeedRespond;

/**模块工作状态*/
static char gModuleWorkState = MODULE_WORK_STATE_IDLE;
char gSmartMode = SMART_MODE_EASYLINK;
/*网络配置标志*/
uint8_t gNetConfigureFlag = SMART_CONFIG_STAT_IDEL; 



/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	UARTx_Init();
	rb_new(&gUartRingBuff);//wifi全局缓存
	KEY_GPIO_Init();
	TIM3_Int_Init(7199, 9);

}

/**
*设置需要得到的回复命令
*
*/
int SetNeedRespondData(char workState,char checkType, char *cmd, uint8_t *data, int dataLen, char *state)
{
	
	int flag = 0;
	memset(&gNeedRespond, 0, sizeof(TNeedRespond));
	if(cmd)
	{
		memcpy(gNeedRespond.cmd, cmd, strlen(cmd));
		flag = 1;
	}
	if(data && dataLen > 0)
	{
		memcpy(gNeedRespond.data, data, dataLen);
		gNeedRespond.dataLen = dataLen;
		flag = 1;
	}
	if(state)
	{
		memcpy(gNeedRespond.state, state, strlen(state));
		flag = 1;
	}
	gNeedRespond.workState = workState;
	gNeedRespond.checkType = checkType;
	gNeedRespond.respondState = RESPONDE_STATE_WAITING;
	gNeedRespond.count = 8;
	gNeedRespond.flag = flag;
	return 0;
}


/**
*设置需要得到的回复命令
*
*/
int SetNeedRespondRespondState(char respondState)
{
	
	if(gNeedRespond.flag)
	{
		gNeedRespond.respondState = respondState;
		printf("SetNeedRespondRespondState respondState=%d\r\n",gNeedRespond.respondState);
	}
	return 0;
}


/**
*获取需要回复命令缓存
*
*/
PNeedRespond GetNeedRespondData(void)
{
	
	return &gNeedRespond;
}

/**
*清除需要回复命令缓存
*
*/
void ClearNeedRespondData(void)
{
	
	memset(&gNeedRespond, 0, sizeof(TNeedRespond));
}

/**
*	检查需要回复的的状态
*@param [in] workState 工作的状态
*@param [in] respond 应答缓存
*@retval 
* 0 表示
*/
int CheckNeedRespondMatchState(int workState, PNeedRespond needRespond)
{
	if(needRespond == NULL)
	{
		return -1;
	}
	
	if( needRespond->workState == workState)
	{
		//说明上一次的ＡＴ命令发送并且收到了成功的服务
		if(needRespond->respondState == RESPONDE_STATE_OK)
		{
			printf("workState =%d Match ok\r\n",workState);
		}
		else if(needRespond->respondState == RESPONDE_STATE_WAITING)
		{
			//说明还没收到回复
			if(needRespond->count > 0)
			{
				needRespond->count--;
				if(needRespond->count==0)
				{
					needRespond->respondState = RESPONDE_STATE_TIMEOUT;
					printf(" workState =%d timeout \r\n",workState);
				}
			}
			
		}
	}
	return needRespond->respondState;
}


void HandleKey(void)
{
	int keyState = 0;
	keyState = ReadKeyValue();
	if(keyState & PRESS_KEY1)//可以加其他的Key
	{
		if((keyState & KEY_UP))
		{
			if(gNetConfigureFlag == SMART_CONFIG_STAT_IDEL)
			{
				gNetConfigureFlag = SMART_CONFIG_STAT_NEED_START;
			}
			else if(gNetConfigureFlag ==SMART_CONFIG_STAT_STARTING)
			{
				gNetConfigureFlag = SMART_CONFIG_STAT_NEED_STOP;
			}
			printf("PRESS_KEY1 KEY_UP gNetConfigureFlag=%d\r\n",gNetConfigureFlag);
		}
	}

}


/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	int ret = 0;
	int count = 0;
	int newstate = 1;
	
	TMachipAtRespond atrespondData;
	PNeedRespond needRespond;
	SystemInit();	
	HW_Init();
	printf("Firmware Edition=%s\r\n",MAIN_VERSION);
	printf("YinErDa UART Test Demo Starting\r\n");
	needRespond = GetNeedRespondData();
	while(1)
	{
		HandleKey();
		
		if(gNetConfigureFlag == SMART_CONFIG_STAT_NEED_START
			)//&& needRespond->flag ==0)
		{
			//需要等待其他命令结束完后才能执行smart
			gModuleWorkState = MODULE_WORK_STATE_NEED_SMARTSTART;
			ClearNeedRespondData();
			newstate=1;
		}
		else if(gNetConfigureFlag==SMART_CONFIG_STAT_NEED_STOP
			)//&& needRespond->flag ==0 )
		{
			//需要等待其他命令结束完后才能执行smart
			gModuleWorkState = MODULE_WORK_STATE_NEED_SMARTSTART;
			ClearNeedRespondData();
			newstate=1;
		}
		
	 
		//处理发送状态
		switch(gModuleWorkState)
		{
			case MODULE_WORK_STATE_IDLE:
			{
				
				if(newstate == 1 )
				{
					count = 300;
				}
				count--;
				if(newstate ==0 && count > 0)
				{
					break;
				}
				else if(count == 0)
				{
					count = 300;
				}
				newstate = 0;
				printf("MODULE_WORK_STATE_IDLE \r\n");
				ret = CheckNeedRespondMatchState(MODULE_WORK_STATE_IDLE,needRespond);
				if(ret == RESPONDE_STATE_OK)
				{
					ClearNeedRespondData();
					gModuleWorkState = MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE;
					newstate=1;
					printf("MODULE_WORK_STATE_IDLE ok \r\n");
					break;
				}
				else if(ret == RESPONDE_STATE_WAITING)
				{
					break;
				}
				
				MachipCloseUartBackDisplay();
				SetNeedRespondData(MODULE_WORK_STATE_IDLE,RESPOND_CHECK_STATE,"UARTE", NULL, 0, "OK");
				newstate=1;
				break;
			}
			case MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE:
			{
				//这个是为了第一次进入状态需要执行，后续的进入需要延时
				if(newstate == 1 )
				{
					count = 300;
				}
				count--;
				if(newstate ==0 && count > 0)
				{
					break;
				}
				else if(count == 0)
				{
					count = 300;
				}
				newstate = 0;
				
				printf("MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE \r\n");
				
				ret = CheckNeedRespondMatchState(MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,needRespond);
				if(ret == RESPONDE_STATE_OK)
				{
					ClearNeedRespondData();
					gModuleWorkState = MODULE_WORK_STATE_CONNECTED_AP;
					newstate = 1;
					printf("MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE ok \r\n");
					break;
				}
				else if(ret == RESPONDE_STATE_WAITING)
				{
					break;
				}
				
				GetStationConnectState();
				SetNeedRespondData(MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,RESPOND_CHECK_CMD_DATA,"WJAPS", (uint8_t *)"STATION_UP", strlen("STATION_UP"), "OK");
				
				break;
			}
			case MODULE_WORK_STATE_CONNECTED_AP:
			{
				if(newstate==1)
				{
					printf("MODULE_WORK_STATE_CONNECTED_AP \r\n");
				}
				newstate = 0;
				break;
			}
			case MODULE_WORK_STATE_NEED_SMARTSTART:
			{
				
				if(newstate == 1 )
				{
					count = 100;
					gNetConfigureFlag = SMART_CONFIG_STAT_STARTING;
				}
				count--;
				if(newstate ==0 && count > 0)
				{
					break;
				}
				else if(count == 0)
				{
					count = 300;
				}
				newstate = 0;
				
				printf("MODULE_WORK_STATE_NEED_SMARTSTART \r\n");
				ret = CheckNeedRespondMatchState(MODULE_WORK_STATE_NEED_SMARTSTART,needRespond);
				if(ret == RESPONDE_STATE_OK)
				{
					ClearNeedRespondData();
					gModuleWorkState = MODULE_WORK_STATE_SMARTSTART_STARTING;
					newstate=1;
					printf("MODULE_WORK_STATE_NEED_SMARTSTART ok \r\n");
					break;
				}
				else if(ret == RESPONDE_STATE_WAITING)
				{
					break;
				}
				
				MachipStartSmart(gSmartMode);
				SetNeedRespondData(MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,RESPOND_CHECK_STATE,"SMARTSTART", NULL, 0, "OK");
				break;
			}
			
			case MODULE_WORK_STATE_SMARTSTART_STARTING:
			{
				
				//这个是为了第一次进入状态需要执行，后续的进入需要延时
				if(newstate == 1 )
				{
					count = 800;
				}
				count--;
				if(newstate ==0 && count > 0)
				{
					break;
				}
				else if(count == 0)
				{
					count = 800;
				}
				newstate = 0;
				
				printf("MODULE_WORK_STATE_SMARTSTART_STARTING need Check AP_STATE \r\n");
				ret = CheckNeedRespondMatchState(MODULE_WORK_STATE_SMARTSTART_STARTING,needRespond);
				if(ret == RESPONDE_STATE_OK)
				{
					ClearNeedRespondData();
					gModuleWorkState = MODULE_WORK_STATE_NEED_SMARTSTOP;
					newstate = 1;
					printf("MODULE_WORK_STATE_SMARTSTART_STARTING ap in connected \r\n");
					break;
				}
				else if(ret == RESPONDE_STATE_WAITING)
				{
					break;
				}
				
				GetStationConnectState();
				SetNeedRespondData(MODULE_WORK_STATE_SMARTSTART_STARTING,RESPOND_CHECK_CMD_DATA,"WJAPS", (uint8_t *)"STATION_UP", strlen("STATION_UP"), "OK");
			
				
				break;
			}
			case MODULE_WORK_STATE_NEED_SMARTSTOP:
			{
				printf("MODULE_WORK_STATE_NEED_SMARTSTOP \r\n");
				ret = CheckNeedRespondMatchState(MODULE_WORK_STATE_NEED_SMARTSTOP,needRespond);
				if(ret == RESPONDE_STATE_OK)
				{
					ClearNeedRespondData();
					gModuleWorkState = MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE;
					newstate = 1;
					printf("MODULE_WORK_STATE_NEED_SMARTSTOP ok \r\n");
					break;
				}
				else if(ret == RESPONDE_STATE_WAITING)
				{
					break;
				}
				
				MachipStopSmart(gSmartMode);
				SetNeedRespondData(MODULE_WORK_STATE_NEED_SMARTSTOP,RESPOND_CHECK_STATE,"SMARTSTOP", NULL, 0, "OK");
				gNetConfigureFlag = SMART_CONFIG_STAT_IDEL;
				break;
				
			}
			
		}
		
		//处理串口收到的数据
		memset(&atrespondData, 0, sizeof(TMachipAtRespond));
		ret = CheckMachipAtData(&atrespondData, 500);
		if(ret == 0)
		{
			needRespond = GetNeedRespondData();
			printf("flag=%d,checkType=%d,respondState=%d,cmd=%s,data=%s\r\n",needRespond->flag,needRespond->checkType,needRespond->respondState,needRespond->cmd,needRespond->data);
			if(needRespond->flag)
			{
				
				if(needRespond->checkType == RESPOND_CHECK_STATE)
				{
					if(memcmp("OK",atrespondData.state,strlen("OK")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_OK);
					}
					else if(memcmp("ERROR",atrespondData.state,strlen("ERROR")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_ERROR);
					}
				}
				if(needRespond->checkType ==RESPOND_CHECK_CMD_DATA)
				{
					if(memcmp("ERROR",atrespondData.state,strlen("ERROR")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_ERROR);
					}
					else if(memcmp(needRespond->cmd,atrespondData.cmd,strlen(needRespond->cmd)) == 0 
						&&memcmp(needRespond->data,atrespondData.data,needRespond->dataLen) == 0 )
					{
						SetNeedRespondRespondState(RESPONDE_STATE_OK);
					}
				
				}
			}

			DebugHex((uint8_t*)atrespondData.cmd, strlen(atrespondData.cmd));
			DebugHex(atrespondData.data, atrespondData.dataLen);
		}
		else if(ret == -2)
		{
			Delay_ms(10);
		}
	}
	return 0;
}
