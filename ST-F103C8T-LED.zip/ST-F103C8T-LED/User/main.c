/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_led/Hal_led.h"
#include "delay.h"

#define MAIN_VERSION		"Ver Led 1.0 "__DATE__

/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	LED_GPIO_Init();

}

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	
	SystemInit();	
	HW_Init();
	while(1)
	{
			LED_ON(LED1);
			LED_ON(LED2);
			LED_ON(LED3);
			LED_ON(LED4);
			Delay_ss(1);
			LED_OFF(LED1);
			LED_OFF(LED2);
			LED_OFF(LED3);
			LED_OFF(LED4);
		  Delay_ss(1);
	
	}

}
