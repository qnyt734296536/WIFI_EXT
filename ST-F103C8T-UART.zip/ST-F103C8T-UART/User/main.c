/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_Usart/hal_uart.h"
#include "delay.h"


uint8_t gUart1ReciveBuf[128]; //串口接手全局变量
int gUart1ReciveCount=0;//串口接收缓存数量
#define MAIN_VERSION		"Ver UART 1.0 "__DATE__







/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	UARTx_Init();

}





/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	

	SystemInit();	
	HW_Init();
	printf("Firmware Edition=%s\r\n",MAIN_VERSION);
	printf("YinErDa UART Test Demo Starting\r\n");
	while(1)
	{
		Delay_ss(1);
		if(gUart1ReciveCount)
		{
			SendDataToUsart(USART1, gUart1ReciveBuf, gUart1ReciveCount);
			printf("\r\n");
			gUart1ReciveCount = 0;
		}
		DebugStrToUsart(DEBUGUSART, DEBUG_LOG_CATE_SYS, "you can send string to ST-F103C8T6\r\n");//和prinf 一样
	}
	return 0;
}
