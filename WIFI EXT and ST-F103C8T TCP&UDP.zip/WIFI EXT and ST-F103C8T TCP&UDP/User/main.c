/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_Usart/hal_uart.h"
#include "ringbuffer.h"
#include "delay.h"
#include "machip_at.h"


/**
*云链接状态
*/
enum _module_work_state
{
	MODULE_WORK_STATE_IDLE,//空闲状态
	MODULE_WORK_STATE_NEED_CONNECT_AP,//需要连接AP
	MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,//需要检查连接AP
	MODULE_WORK_STATE_CONNECTED_AP,//连接AP成功
	MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER,//需要连接TCP
	MODULE_WORK_STATE_WAIT_CONNECTED_TCP_SERVER,//等待连接TCP服务
	MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE,//检查TCP 服务状态
	MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER, //需要停止一个连接
	MODULE_WORK_STATE_CONNECTED_TCP_SERVER,//连接TCP成功
	
};

#define MAIN_VERSION		"Ver TCP UDP 1.0 "__DATE__

#define ROUTER_SSID			"yinerda"		//替换需要连接的路由器的WIFI名
#define ROUTER_KEY			"tb18938045680"//替换需要连接的路由器的密码

#define TCP_SERVER_IP		"192.168.1.138"//替换需要连接的TCP serverIP
#define TCP_SERVER_PORT	6666 //替换需要连接的TCP server port

#define TCP_LOCALITY_PORT	1111 //TCP client 需要的本地TCP端口

/*串口接收缓存*/
RingBuffer gUartRingBuff;	
/**全局的需要得到应答的命令*/
TNeedRespond gNeedRespond;

/**模块工作状态*/
static char gModuleWorkState = MODULE_WORK_STATE_IDLE;

int gTcpClinetId = 0;
char gNetTcpConnectFlag = 0;




/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	UARTx_Init();
	rb_new(&gUartRingBuff);//wifi全局缓存

}

/**
*设置需要得到的回复命令
*
*/
int SetNeedRespondData(char workState,char checkType, char *cmd, uint8_t *data, int dataLen, char *state)
{
	
	int flag = 0;
	memset(&gNeedRespond, 0, sizeof(TNeedRespond));
	if(cmd)
	{
		memcpy(gNeedRespond.cmd, cmd, strlen(cmd));
		flag = 1;
	}
	if(data && dataLen > 0)
	{
		memcpy(gNeedRespond.data, data, dataLen);
		gNeedRespond.dataLen = dataLen;
		flag = 1;
	}
	if(state)
	{
		memcpy(gNeedRespond.state, state, strlen(state));
		flag = 1;
	}
	gNeedRespond.workState = workState;
	gNeedRespond.checkType = checkType;
	gNeedRespond.count = 3;
	gNeedRespond.flag = flag;
	return 0;
}


/**
*设置需要得到的回复命令
*
*/
int SetNeedRespondRespondState(char respondState)
{
	
	if(gNeedRespond.flag)
	{
		gNeedRespond.respondState = respondState;
		printf("SetNeedRespondRespondState respondState=%d\r\n",gNeedRespond.respondState);
	}
	return 0;
}


/**
*获取需要回复命令缓存
*
*/
PNeedRespond GetNeedRespondData(void)
{
	
	return &gNeedRespond;
}

/**
*清除需要回复命令缓存
*
*/
void ClearNeedRespondData(void)
{
	
	memset(&gNeedRespond, 0, sizeof(TNeedRespond));
}

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	int ret = 0;
	TMachipAtRespond atrespondData;
	PNeedRespond needRespond;
	SystemInit();	
	HW_Init();
	printf("Firmware Edition=%s\r\n",MAIN_VERSION);
	printf("YinErDa UART Test Demo Starting\r\n");
	while(1)
	{
		//处理发送状态
		switch(gModuleWorkState)
		{
			case MODULE_WORK_STATE_IDLE:
			{
				printf("MODULE_WORK_STATE_IDLE \r\n");
				MachipCloseUartBackDisplay();
				Delay_ss(3);
				gModuleWorkState = MODULE_WORK_STATE_NEED_CONNECT_AP;
				break;
			}
			case MODULE_WORK_STATE_NEED_CONNECT_AP:
			{
				printf("MODULE_WORK_STATE_NEED_CONNECT_AP \r\n");
				needRespond = GetNeedRespondData();
				if( needRespond->workState == MODULE_WORK_STATE_NEED_CONNECT_AP)
				{
					//说明上一次的ＡＴ命令发送并且收到了成功的服务
					if(needRespond->respondState == RESPONDE_STATE_OK)
					{
						gModuleWorkState = MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE;
						printf("MODULE_WORK_STATE_NEED_CONNECT_AP CMD OK\r\n");
						ClearNeedRespondData();
						break;
					}
					else if(needRespond->respondState == RESPONDE_STATE_IDEL)
					{
						//说明还没收到回复
						break;
					}
				}
				MachipStationConnectAp((uint8_t *)ROUTER_SSID,strlen(ROUTER_SSID), ROUTER_KEY);
				SetNeedRespondData(MODULE_WORK_STATE_NEED_CONNECT_AP,RESPOND_CHECK_STATE,"WJAP", NULL, 0, "OK");
				break;
			}
			case MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE:
			{
				printf("MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE \r\n");
				needRespond = GetNeedRespondData();
				if( needRespond->workState == MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE)
				{
					//说明上一次的ＡＴ命令发送并且收到了成功的服务
					if(needRespond->respondState == RESPONDE_STATE_OK)
					{
						gModuleWorkState = MODULE_WORK_STATE_CONNECTED_AP;
						printf("MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE conncted OK\r\n");
						ClearNeedRespondData();
						break;
					}
					else if(needRespond->respondState == RESPONDE_STATE_IDEL)
					{
						//说明还没收到回复
						if(needRespond->count > 0)
						{
							needRespond->count--;
							if(needRespond->count==0)
							{
								//需要重新发送
								printf("MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE timeout \r\n");
							}
							else
							{
								Delay_ss(1);
								break;
							}
						}
						
					}
					
				}
				GetStationConnectState();
				SetNeedRespondData(MODULE_WORK_STATE_NEED_CHECK_CONNECT_AP_STATE,RESPOND_CHECK_CMD_DATA,"WJAPS", (uint8_t *)"STATION_UP", strlen("STATION_UP"), "OK");
				break;
			}
			case MODULE_WORK_STATE_CONNECTED_AP:
			{
				printf("MODULE_WORK_STATE_CONNECTED_AP \r\n");
				gModuleWorkState = MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER;
				break;
			}
			case MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER:
			{
				printf("MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER \r\n");
				needRespond = GetNeedRespondData();
				if( needRespond->workState == MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER)
				{
					//说明上一次的ＡＴ命令发送并且收到了成功的服务
					if(needRespond->respondState == RESPONDE_STATE_OK)
					{
						gModuleWorkState = MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE;
						printf("MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER conncted OK\r\n");
						ClearNeedRespondData();
						break;
					}
					else if(needRespond->respondState == RESPONDE_STATE_ERROR)
					{
						printf("MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER conncted need close \r\n");
						gModuleWorkState = MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER;
						
					}
					else if(needRespond->respondState == RESPONDE_STATE_IDEL)
					{
						//说明还没收到回复
						
						if(needRespond->count > 0)
						{
							needRespond->count--;
							if(needRespond->count==0)
							{
								//需要重新发送
								printf("MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER timeout \r\n");
							}
							else
							{
								Delay_ss(1);
								break;
							}
						}
					}
					
				}
				MachipStartNetWorkConnect(gTcpClinetId,CIPSTART_TYPE_TCP_CLIENT,TCP_SERVER_IP,TCP_SERVER_PORT,TCP_LOCALITY_PORT);
				SetNeedRespondData(MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER,RESPOND_CHECK_STATE,"CIPSTART", NULL, 0, "OK");
				break;
			}
			
			case MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER:
			{
			
				printf("MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER \r\n");
				needRespond = GetNeedRespondData();
				if( needRespond->workState == MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER)
				{
					//说明上一次的ＡＴ命令发送并且收到了成功的服务
					if(needRespond->respondState == RESPONDE_STATE_OK)
					{
						gModuleWorkState = MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER;
						printf("MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER  OK need MODULE_WORK_STATE_NEED_CONNECT_TCP_SERVER\r\n");
						ClearNeedRespondData();
						break;
					}
					else if(needRespond->respondState == RESPONDE_STATE_ERROR)
					{
						printf("MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER ERR \r\n");
					}
					else if(needRespond->respondState == RESPONDE_STATE_IDEL)
					{
						//说明还没收到回复
						
						if(needRespond->count > 0)
						{
							needRespond->count--;
							if(needRespond->count==0)
							{
								//需要重新发送
								printf("MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER timeout \r\n");
							}
							else
							{
								Delay_ss(1);
								break;
							}
						}
					}
					
				}
				MachipStopNetServerConnect(gTcpClinetId);
				SetNeedRespondData(MODULE_WORK_STATE_NEED_STOP_CONNECTED_SERVER,RESPOND_CHECK_STATE,"CIPSTOP", NULL, 0, "OK");
				
				break;
			}
			case MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE:
			{
				printf("MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE \r\n");
				
				needRespond = GetNeedRespondData();
				if( needRespond->workState == MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE)
				{
					//说明上一次的ＡＴ命令发送并且收到了成功的服务
					if(needRespond->respondState == RESPONDE_STATE_OK)
					{
						gModuleWorkState = MODULE_WORK_STATE_CONNECTED_TCP_SERVER;
						printf("MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE conncted OK\r\n");
						ClearNeedRespondData();
						break;
					}
					else if(needRespond->respondState == RESPONDE_STATE_IDEL)
					{
						//说明还没收到回复
						break;
					}
					
					
				}
				MachipGetNetServerConnect(gTcpClinetId);
				char temp[32];
				memset(temp, 0, sizeof(temp));
				sprintf(temp,"%d,connected",gTcpClinetId);
				SetNeedRespondData(MODULE_WORK_STATE_CHECK_CONNECT_TCP_SERVER_STATE,RESPOND_CHECK_STATE,"CIPSTATUS", (uint8_t *)temp, strlen(temp), "OK");
	
				break;
			}
			case MODULE_WORK_STATE_CONNECTED_TCP_SERVER:
			{
				if(gNetTcpConnectFlag == 0)
				{
					printf("MODULE_WORK_STATE_CONNECTED_TCP_SERVER \r\n");
					gNetTcpConnectFlag = 1;
				}
				break;
			}
		
		}
		
		//处理串口收到的数据
		memset(&atrespondData, 0, sizeof(TMachipAtRespond));
		ret = CheckMachipAtData(&atrespondData, 500);
		if(ret == 0)
		{
			needRespond = GetNeedRespondData();
			printf("flag=%d,checkType=%d,respondState=%d,cmd=%s,data=%s\r\n",needRespond->flag,needRespond->checkType,needRespond->respondState,needRespond->cmd,needRespond->data);
			if(needRespond->flag)
			{
				
				if(needRespond->checkType == RESPOND_CHECK_STATE)
				{
					if(memcmp("OK",atrespondData.state,strlen("OK")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_OK);
					}
					else if(memcmp("ERROR",atrespondData.state,strlen("ERROR")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_ERROR);
					}
				}
				if(needRespond->checkType ==RESPOND_CHECK_CMD_DATA)
				{
					if(memcmp("ERROR",atrespondData.state,strlen("ERROR")) == 0)
					{
						SetNeedRespondRespondState(RESPONDE_STATE_ERROR);
					}
					else if(memcmp(needRespond->cmd,atrespondData.cmd,strlen(needRespond->cmd)) == 0 
						&&memcmp(needRespond->data,atrespondData.data,needRespond->dataLen) == 0 )
					{
						SetNeedRespondRespondState(RESPONDE_STATE_OK);
					}
				
				}
			}

			DebugHex((uint8_t*)atrespondData.cmd, strlen(atrespondData.cmd));
			DebugHex(atrespondData.data, atrespondData.dataLen);
		}
	}
	return 0;
}
