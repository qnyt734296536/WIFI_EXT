/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_Usart/hal_uart.h"
#include "Hal_key/hal_key.h"
#include "Hal_rgb_led/hal_rgb_led.h"
#include "delay.h"


uint8_t gUart1ReciveBuf[128]; //串口接手全局变量
int gUart1ReciveCount=0;//串口接收缓存数量
#define MAIN_VERSION		"Ver UART 1.0 "__DATE__







/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	UARTx_Init();
	KEY_GPIO_Init();
	TIM3_Int_Init(7199,9);
	RGB_LED_Init();

}





/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	
	uint8_t keystate = 0;
	uint8_t rgbLedState = 0;
	SystemInit();	
	HW_Init();
	printf("Firmware Edition=%s\r\n",MAIN_VERSION);
	printf("YinErDa RGB LED Test Demo Starting\r\n");
	RGB_PowerOnOff(1);
	LED_RGB_Control(255, 255, 255);
	while(1)
	{
		keystate = ReadKeyValue();
		if(keystate & PRESS_KEY1)//可以加其他的Key
		{
			if((keystate & KEY_UP))
			{
				rgbLedState++;
				printf("PRESS_KEY1 KEY_UP rgbLedState=%d\r\n",rgbLedState);
				if(rgbLedState == 1)
				{
					LED_RGB_Control(255, 0, 0);
				}
				else if(rgbLedState == 2)
				{
					LED_RGB_Control(0, 255, 0);
				}
				else if(rgbLedState == 3)
				{
					LED_RGB_Control(0, 0, 255);
				}
				else if(rgbLedState == 4)
				{
					RGB_PowerOnOff(0);
					printf("close RGB\r\n");
				}
				else if(rgbLedState == 5)
				{
					printf("open RGB\r\n");
					RGB_PowerOnOff(1);
					LED_RGB_Control(255, 255, 255);
					rgbLedState= 0;
				}

			}	

	 }
		

	 
	}
	return 0;
}
