/**
********************************************************
*
* @file      main.c
*********************************************************/


#include <stdio.h>
#include <string.h>
#include <stm32f10x.h>
#include "Hal_Usart/hal_uart.h"
#include "Hal_key/hal_key.h"
#include "delay.h"


uint8_t gUart1ReciveBuf[128]; //串口接手全局变量
int gUart1ReciveCount=0;//串口接收缓存数量
#define MAIN_VERSION		"Ver UART 1.0 "__DATE__







/** 初始化硬件
  */
void HW_Init(void)
{
	Delay_Init(72);	
	UARTx_Init();
	KEY_GPIO_Init();
	TIM3_Int_Init(7199,9);

}





/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{	
	
	uint8_t keystate = 0;
	SystemInit();	
	HW_Init();
	printf("Firmware Edition=%s\r\n",MAIN_VERSION);
	printf("YinErDa Key Test Demo Starting\r\n");
	while(1)
	{
		keystate = ReadKeyValue();
		if(keystate & PRESS_KEY1)//可以加其他的Key
		{
			if((keystate & KEY_UP))
			{
				printf("PRESS_KEY1 KEY_UP\r\n");
			}
			if((keystate & KEY_LONG)) //按键超过2s
			{
				printf("PRESS_KEY1 KEY  LONG\r\n");
			}
	 }
	}
	return 0;
}
